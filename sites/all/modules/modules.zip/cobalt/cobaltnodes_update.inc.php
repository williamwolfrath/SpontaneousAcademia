<?php
// $Id: cobaltnodes_update.inc.php,v 1.2 2009/02/20 17:30:14 hugowetterberg Exp $

/* Remove this line if you want to try out the updating mechanism
function cobaltnodes_cobalt_js_update($from, $to) {
  drupal_add_js(drupal_get_path('module', 'cobaltnodes') . '/js/cobalt.nodes.update.js');
}
//*/