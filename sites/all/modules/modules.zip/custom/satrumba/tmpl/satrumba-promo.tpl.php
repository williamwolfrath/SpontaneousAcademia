<?php
// main page for Trumba calendar functionality
?>


<div id="trumba-promo">
    
    <script type="text/javascript">
        $Trumba.addSpud({
        webName: "kosmos-main",
        spudType : "upcoming" ,
        teaserBase : "http://www.kosmosonline.org/trumba-test" });
    </script>
    <noscript>Your browser must support JavaScript to view this content. 
        Please enable JavaScript in your browser settings then try again. 
    <a href='http://www.trumba.com'>Events calendar powered by Trumba</a></noscript>
    
</div>

