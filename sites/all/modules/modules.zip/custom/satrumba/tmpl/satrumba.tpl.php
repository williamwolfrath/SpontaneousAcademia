<?php
// main page for Trumba calendar functionality
?>


<div id="trumba">
    
    <script type="text/javascript">
        $Trumba.addSpud({
            webName: "kosmos-main",
            spudType : "chooser" });
    </script>
    
       <br/>
    <hr/>
    <br/>
    
    <script type="text/javascript" src="http://www.trumba.com/scripts/spuds.js"></script>
<script type="text/javascript">
$Trumba.addSpud({
webName: "kosmos-main",
spudType : "mix" });
</script>
    
    <br/>
    <hr/>
    <br/>
    
    
    <script type="text/javascript">
        $Trumba.addSpud({
            webName: "kosmos-main",
            spudType : "main" });
    </script>
    
    <br/>
    <hr/>
    <br/>
    
    <div id="trumba-event-submit">
    <script type="text/javascript">
    trumbaInsertSubmitEventForm({
        code: "s9ua1f0r681xgzw5sdhh7s5wa7",
        width: 385,
        height: 775,
        backgroundColor: "white" });
    </script>
    </div>
    
    <noscript>Your browser must support JavaScript to view this content. 
        Please enable JavaScript in your browser settings then try again. 
        <a href='http://www.trumba.com'>Events calendar powered by Trumba</a>
    </noscript>
    
</div>


