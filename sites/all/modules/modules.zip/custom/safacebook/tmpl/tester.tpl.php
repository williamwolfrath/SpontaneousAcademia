<div id="fb">
        <div id="fb-testarea">
                Test Area.
                <div id="fb-status">
                        FB Status area.
                </div>
        </div>
        
        
</div>