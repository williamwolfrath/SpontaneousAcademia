$Id: README.txt,v 1.4 2008/07/28 18:38:38 yaph Exp $
Drupal diggthis README
---------------------------------
Author: Ramiro G�mez (http://www.ramiro.org)

This program is free software; you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
(see LICENSE.txt)
Requirements
------------
This module requires Drupal 6.X.

Overview:
--------
This module adds a Digg this button to your nodes. If the story
is not yet submitted to Digg a "Digg this story" button is displayed.
If the story was already submitted a button showing the number of
Diggs you received is displayed.

Installation and configuration:
------------------------------
Simply extract the download package in your modules directory and 
then enable the module in 'admin/build/modules/'.
For configuration options go to 'admin/content/diggthis'.