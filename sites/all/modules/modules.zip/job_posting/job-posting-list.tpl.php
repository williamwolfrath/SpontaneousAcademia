<?php
// $Id: job-posting-list.tpl.php,v 1.1.2.3 2008/05/06 19:42:12 gmarus Exp $

/**
 * @file job-posting-list.tpl.php
 * Default implementation for the display of job posting list pages
 * 
 */
?>
<div id="job-posting-nodelist">
<?php print $listings; ?>
</div>