This is the Drupal 6.x version of this module

In order to use this module you must FIRST install the Pear log package on your web server.
You may download this here :  http://pear.php.net/package/Log

On Debian Linux this may be done as follows
*  apt-get install php-log

You also need to create your log directory, and set the permissions accordingly.
Again, on Debian Linux, this may be done as follows

* mkdir /var/log/drupal
* chown www-data.www-data /var/log/drupal 
